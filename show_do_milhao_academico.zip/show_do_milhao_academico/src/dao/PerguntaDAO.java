package dao;
import model.Pergunta;
import model.Resposta;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PerguntaDAO {
    private final RespostaDAO respostaDAO = new RespostaDAO(); // para integrar respostas
    public boolean cadastrar(Pergunta pergunta) throws SQLException {
        String sql = "INSERT INTO Pergunta (enunciado, id_categoria, id_dificuldade) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pergunta.getEnunciado());
            stmt.setInt(2, pergunta.getIdCategoria());
            stmt.setInt(3, pergunta.getIdDificuldade());
            return stmt.executeUpdate() > 0;
        }
    }

    public List<Pergunta> listarTodas() throws SQLException {
        List<Pergunta> perguntas = new ArrayList<>();
        String sql = "SELECT * FROM Pergunta";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Pergunta pergunta = new Pergunta(
                        rs.getInt("id_pergunta"),
                        rs.getString("enunciado"),
                        rs.getInt("id_categoria"),
                        rs.getInt("id_dificuldade"),
                        rs.getTimestamp("criada_em").toLocalDateTime()
                );

                pergunta.setRespostas(respostaDAO.listarPorPergunta(pergunta.getId()));
                perguntas.add(pergunta);
            }
        }

        return perguntas;
    }

    public Pergunta buscarPorId(int idPergunta) throws SQLException {
        String sql = "SELECT * FROM Pergunta WHERE id_pergunta = ?";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idPergunta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Pergunta pergunta = new Pergunta(
                            rs.getInt("id_pergunta"),
                            rs.getString("enunciado"),
                            rs.getInt("id_categoria"),
                            rs.getInt("id_dificuldade"),
                            rs.getTimestamp("criada_em").toLocalDateTime()
                    );

                    pergunta.setRespostas(respostaDAO.listarPorPergunta(pergunta.getId()));
                    return pergunta;
                }
            }
        }

        return null;
    }

    public boolean atualizar(Pergunta pergunta) throws SQLException {
        String sql = "UPDATE Pergunta SET enunciado = ?, id_categoria = ?, id_dificuldade = ? WHERE id_pergunta = ?";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pergunta.getEnunciado());
            stmt.setInt(2, pergunta.getIdCategoria());
            stmt.setInt(3, pergunta.getIdDificuldade());
            stmt.setInt(4, pergunta.getId());

            return stmt.executeUpdate() > 0;
        }
    }

    public boolean deletar(int idPergunta) throws SQLException {
        String sql = "DELETE FROM Pergunta WHERE id_pergunta = ?";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idPergunta);
            return stmt.executeUpdate() > 0;
        }
    }

    public Pergunta buscarUltimaPorEnunciado(String enunciado) throws SQLException {
        String sql = "SELECT * FROM Pergunta WHERE enunciado = ? ORDER BY id_pergunta DESC LIMIT 1";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, enunciado);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Pergunta pergunta = new Pergunta(
                            rs.getInt("id_pergunta"),
                            rs.getString("enunciado"),
                            rs.getInt("id_categoria"),
                            rs.getInt("id_dificuldade"),
                            rs.getTimestamp("criada_em").toLocalDateTime()
                    );

                    pergunta.setRespostas(respostaDAO.listarPorPergunta(pergunta.getId()));
                    return pergunta;
                }
            }
        }

        return null;
    }
}
