package dao;
import model.Professor;
import model.TipoUsuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class ProfessorDAO {
    //Listar todos os professores (com id_cadastrado_por)
    public List<Professor> listarTodos() throws SQLException {
        List<Professor> professores = new ArrayList<>();
        String sql = """
            SELECT u.id_usuario, u.nome, u.email, u.senha, p.id_cadastrado_por
            FROM Usuario u
            JOIN Professor p ON u.id_usuario = p.id_usuario
            WHERE u.tipo = 'PROFESSOR'
        """;
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Professor professor = new Professor(
                    rs.getInt("id_usuario"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("senha"),
                    TipoUsuario.PROFESSOR
                );
                professor.setIdCadastradoPor(rs.getInt("id_cadastrado_por"));
                professores.add(professor);
            }
        }

        return professores;
    }

    //Listar professores cadastrados por um coordenador
    public List<Professor> listarPorCoordenador(int idCoordenador) throws SQLException {
        List<Professor> professores = new ArrayList<>();

        String sql = """
            SELECT u.id_usuario, u.nome, u.email, u.senha, p.id_cadastrado_por
            FROM Usuario u
            JOIN Professor p ON u.id_usuario = p.id_usuario
            WHERE u.tipo = 'PROFESSOR' AND p.id_cadastrado_por = ?
        """;

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idCoordenador);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Professor professor = new Professor(
                        rs.getInt("id_usuario"),
                        rs.getString("nome"),
                        rs.getString("email"),
                        rs.getString("senha"),
                        TipoUsuario.PROFESSOR
                    );
                    professor.setIdCadastradoPor(rs.getInt("id_cadastrado_por"));
                    professores.add(professor);
                }
            }
        }

        return professores;
    }

    //Deletar da tabela Professor (apenas o vínculo)
    public boolean deletarVinculoProfessor(int idUsuario) throws SQLException {
        String sql = "DELETE FROM Professor WHERE id_usuario = ?";
        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            return stmt.executeUpdate() > 0;
        }
    }
}