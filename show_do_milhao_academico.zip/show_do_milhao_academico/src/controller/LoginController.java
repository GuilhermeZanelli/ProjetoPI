package controller;
import dao.UsuarioDAO;
import model.Usuario;
import java.sql.SQLException;
public class LoginController {
    private final UsuarioDAO usuarioDAO;
    public LoginController(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    public Usuario login(String email, String senha) throws SQLException {
        Usuario usuario = usuarioDAO.buscarPorEmail(email);
        if (usuario != null && usuario.getSenha().equals(senha)) {
            return usuario;
        }
        return null;
    }
}