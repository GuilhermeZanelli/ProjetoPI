package controller;
import dao.ProfessorDAO;
import model.Professor;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
public class ProfessorController {
    private final ProfessorDAO professorDAO;
    public ProfessorController(ProfessorDAO professorDAO) {
        this.professorDAO = Objects.requireNonNull(professorDAO);
    }

    //Lista todos os professores do sistema
    public List<Professor> listarProfessores() throws SQLException {
        return professorDAO.listarTodos();
    }

    //Lista professores vinculados a um coordenador
    public List<Professor> listarPorCoordenador(int idCoordenador) throws SQLException {
        return professorDAO.listarPorCoordenador(idCoordenador);
    }

    //Remove vínculo da tabela Professor
    public boolean deletarVinculoProfessor(int idUsuario) throws SQLException {
        return professorDAO.deletarVinculoProfessor(idUsuario);
    }
}