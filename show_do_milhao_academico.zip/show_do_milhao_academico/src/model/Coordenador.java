package model;
public class Coordenador extends Usuario {
    public Coordenador(int id, String nome, String email, String senha) {
        super(id, nome, email, senha, TipoUsuario.COORDENADOR);
    }

    public String toString() {
        return "Coordenador{" +
                "id=" + getId() +
                ", nome='" + getNome() + '\'' +
                ", email='" + getEmail() + '\'' +
                '}';
    }
}