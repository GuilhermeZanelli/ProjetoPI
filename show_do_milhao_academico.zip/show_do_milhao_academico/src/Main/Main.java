package main;
import view.TelaLogin;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Garante que a interface seja iniciada na thread certa
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.out.println("Tema padrão será usado.");
            }

            new TelaLogin(); // ponto de entrada do sistema
        });
    }
}
